#include <iostream>
#include <string>
#include <stack>
using namespace std;

bool simulatePDA(const string& input) {
    stack<char> stack;
    enum State { q_start, q_read_b };
    State currentState = q_start;

    for (char c : input) {
        switch (currentState) {
            case q_start:
                if (c == 'a') {
                    stack.push('$');
                } else if (c == 'b') {
                    currentState = q_read_b;
                    if (stack.empty()) return false;
                    stack.pop();
                } else {
                    return false; // Invalid character
                }
                break;
            case q_read_b:
                if (c == 'b') {
                    if (stack.empty()) return false;
                    stack.pop();
                } else {
                    return false; // 'a' after 'b'
                }
                break;
        }
    }
    // Final check: only accept if the stack is empty
    return stack.empty();
}

bool parseS(const string& input, int& index) {
    // Check for the S -> aSb rule
    if (index < input.length() && input[index] == 'a') {
        // 1. Consume the 'a'
        index++;

        // 2. Try to parse the middle 'S' recursively
        if (!parseS(input, index)) {
            return false; // Middle 'S' parse failed
        }

        // 3. Check for and consume the 'b'
        if (index < input.length() && input[index] == 'b') {
            index++;
            return true; // Successfully parsed 'aSb'
        } else {
            return false; // 'a' was not followed by 'b'
        }
    }
    
    // If it's not 'a', it must be the S -> ε (epsilon) rule.
    return true;
}

bool parseCFG(const string& input) {
    int currentIndex = 0;
    bool success = parseS(input, currentIndex);

    return success && (currentIndex == input.length());
}


int main() {
    string userInput;
    int test_cases;
    cout << "--- CFG-PDA Equivalence Demo for L = {a^n b^n} ---" << endl;
    cout << "Input the number of test cases: " << endl;
    cin >> test_cases;
    cin.ignore();

    while (test_cases-- > 0) {
        cout << "\nEnter a string (e.g., aabb, ab, aab, abb, ba): ";
        getline(cin, userInput);
        
        cout << "\nAnalyzing string: \"" << userInput << "\"" << endl;
        bool pda_result = simulatePDA(userInput);
        bool cfg_result = parseCFG(userInput);

        cout << "1. PDA Simulator Result: " 
                << (pda_result ? "ACCEPT" : "REJECT") << endl;
                
        cout << "2. CFG Parser Result:    " 
                << (cfg_result ? "ACCEPT" : "REJECT") << endl;

        cout << "\n----------------------------------------" << endl;
        if (pda_result == cfg_result) {
            cout << "✅ Success! Both methods agree." << endl;
            cout << "This demonstrates that for this string, the PDA and the CFG are behaving equivalently." << endl;
        } else {
            cout << "❌ Error! The methods disagree. There is a bug in the code." << endl;
        }
    }
    return 0;
}