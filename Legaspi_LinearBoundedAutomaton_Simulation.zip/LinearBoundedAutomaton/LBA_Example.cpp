#include <iostream>
#include <string>
using namespace std;

bool check_language_an_bn_cn(const string& test_str) {
    int a_count = 0;
    int index = 0;

    // First pass: count 'a's
    while (index < test_str.length() && test_str[index] == 'a') {
        a_count++;
        index++;
    }

    // Language requires at least one 'a'
    if (a_count == 0) return false;

    // Second pass: count 'b's
    int b_scanner = 0;
    while (index < test_str.length() && test_str[index] == 'b') {
        b_scanner++;
        index++;
    }

    // Check if 'b' count matches 'a' count
    if (b_scanner != a_count) return false;

    // Third pass: count 'c's
    int c_scanner = 0;
    while (index < test_str.length() && test_str[index] == 'c') {
        c_scanner++;
        index++;
    }

    // Check if 'c' count matches 'a' count
    if (c_scanner != a_count) return false;

    // Final check: ensure we consumed the entire string
    return index == test_str.length();
}


int main() {
    cout << "--- LBA Language Recognizer (a^n b^n c^n) ---" << endl;
    cout << "This LBA machine checks if the input string is of the form a^n b^n c^n." << endl;

    cout << "\nInput how many test cases you want to run: ";
    int test_cases;
    cin >> test_cases;
    cin.ignore();
    
    while (test_cases-- > 0) {
    cout << "\nInput any string composed of the characters 'a', 'b', and 'c', in that specific order to check if that string belongs and is accepted by the language." << endl;
    cout << "String: ";
    string test;
    getline(cin, test);
    cout << "Testing '" << test << "': " 
         << (check_language_an_bn_cn(test) ? "Accepted" : "Rejected") << endl;
    }
        return 0;
}