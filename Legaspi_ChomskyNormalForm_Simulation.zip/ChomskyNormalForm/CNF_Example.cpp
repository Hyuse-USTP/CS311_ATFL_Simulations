#include <iostream>
#include <string>
#include <vector>
using namespace std;


struct Rule {
    string head;
    string production;
};

bool is_variable_char(char c) {
    return c >= 'A' && c <= 'Z';
}

bool is_terminal_char(char c) {
    return c >= 'a' && c <= 'z';
}

bool validateCNF(const vector<Rule>& grammar_rules) {
    for (const auto& prod_rule : grammar_rules) {
        if (prod_rule.head.length() != 1 || !is_variable_char(prod_rule.head[0])) {
            return false;
        }

        if (prod_rule.production.length() == 1) {
            if (!is_terminal_char(prod_rule.production[0])) {
                if (prod_rule.head == "S" && prod_rule.production == "e") {
                    continue; 
                }
                return false;
            }
        } else if (prod_rule.production.length() == 2) {
            if (!is_variable_char(prod_rule.production[0]) || !is_variable_char(prod_rule.production[1])) {
                return false;
            }
        } else {
            return false;
        }
    }
    return true;
}

void printGrammar(const vector<Rule>& grammar, int grammar_number) {
    cout << "\nGrammar " << grammar_number << ":" << endl;
    for (const auto& rule : grammar) {
        cout << rule.head << " -> " << rule.production << endl;
    }
}

int main() {
    cout << "\n--- Chomsky Normal Form (CNF) Validator ---" << endl;
    
    vector<Rule> first_grammar_set = {
        {"X", "YZ"},
        {"Y", "y"},
        {"Z", "z"}
    };
    
    vector<Rule> second_grammar_set = {
        {"X", "YZ"},
        {"Y", "y"},
        {"Z", "abc"}
    };

    vector<Rule> third_grammar_set = {
        {"A", "Bx"},
        {"B", "b"}
    };
    
    printGrammar(first_grammar_set, 1);
    cout << "Grammar 1 check: " << (validateCNF(first_grammar_set) ? "Pass (Is CNF)" : "Fail (Not CNF)") << endl;
    
    printGrammar(second_grammar_set, 2);
    cout << "Grammar 2 check: " << (validateCNF(second_grammar_set) ? "Pass (Is CNF)" : "Fail (Not CNF)") << endl;
    
    printGrammar(third_grammar_set, 3);
    cout << "Grammar 3 check: " << (validateCNF(third_grammar_set) ? "Pass (Is CNF)" : "Fail (Not CNF)") << endl;

    return 0;
}

