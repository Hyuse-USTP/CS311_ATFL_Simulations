#include <iostream>
#include <string>
using namespace std;


bool parseParens(const string& char_stream, int& pos) {
    // Base case: ε (empty string)
    // We hit this if we're at the end or see a closing paren
    if (pos >= char_stream.length() || char_stream[pos] == ')') {
        return true; 
    }

    // Rule: S -> (S)S
    if (char_stream[pos] == '(') {
        pos++; // Consumes '('
        
        // Parses the first 'S'
        if (!parseParens(char_stream, pos)) {
            return false;
        }

        // Checks for the required ')'
        if (pos >= char_stream.length() || char_stream[pos] != ')') {
            return false;
        }
        
        pos++;
        
        // Parses the second 'S'
        return parseParens(char_stream, pos);
    }
    
    // Found an invalid character
    return false;
}

// Wrapper function to start the parse and check the final result
bool verifyBalancedString(const string& char_stream) {
    int pos = 0;
    bool isValid = parseParens(char_stream, pos);
    
    return isValid && (pos == char_stream.length());
}

int main() {
    cout << "\n--- CFG Parser (Balanced Parens) ---" << endl;
    cout << "This CFG parser checks if the input string has balanced parentheses." << endl;
    cout << "For epsilon (empty string), just press Enter" << endl;
    
    cout << "\nHow many test cases do you want to run? ";
    int test_cases;
    cin >> test_cases;
    cin.ignore();
    
    while (test_cases-- > 0){
        cout << "\nInput a string composed of '(' and ')' to check the balance of parentheses in said string." << endl;
        cout << "String: ";
        string test;
        getline(cin, test);
        cout << "Testing '" << test << "': " 
             << (verifyBalancedString(test) ? "Balanced" : "Not Balanced") << endl;
    }
    return 0;
}

