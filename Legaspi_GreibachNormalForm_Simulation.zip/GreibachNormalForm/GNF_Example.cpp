#include <iostream>
#include <string>
#include <vector>
using namespace std;

// Defines a single production rule for a grammar
struct Rule {
    string head; // Left-hand side variable (e.g., "S")
    string production; // Right-hand side body (e.g., "aB")
};

// Checks if a char is an uppercase letter (a Non-Terminal/Variable)
bool is_variable_char(char ch) {
    return ch >= 'A' && ch <= 'Z';
}

// Checks if a char is a lowercase letter (a Terminal)
bool is_terminal_char(char ch) {
    return ch >= 'a' && ch <= 'z';
}

bool validateGNF(const vector<Rule>& grammar_rules) {
    for (const auto& prod_rule : grammar_rules) {
        // LHS must be a single non-terminal
        if (prod_rule.head.length() != 1 || !is_variable_char(prod_rule.head[0])) {
            return false;
        }

        if (prod_rule.production.empty()) {
            return false; // GNF doesn't allow empty productions (ignoring S -> ε for simplicity)
        }
        if (!is_terminal_char(prod_rule.production[0])) {
            return false;
        }
        for (size_t i = 1; i < prod_rule.production.length(); ++i) {
            if (!is_variable_char(prod_rule.production[i])) {
                return false;
            }
        }
    }
    return true; //the grammar is in GNF
}

void printGrammar(const vector<Rule>& grammar, int grammar_number) {
    cout << "\nGrammar " << grammar_number << ":" << endl;
    for (const auto& rule : grammar) {
        cout << rule.head << " -> " << rule.production << endl;
    }
}

int main() {
    cout << "\n--- Greibach Normal Form (GNF) Validator ---" << endl;
    
    vector<Rule> first_test_case = {
        {"X", "aY"},
        {"Y", "bX"},
        {"X", "a"},
        {"Y", "b"}
    };
    
     vector<Rule> second_test_case = {
        {"X", "YA"}, // Invalid: starts with variable
        {"Y", "b"}
    };
    
     vector<Rule> third_test_case = {
        {"X", "ab"} // Invalid: ends with terminal
    };
    
    // Print and validate each grammar
    printGrammar(first_test_case, 1);
    cout << "Grammar 1 check: " << (validateGNF(first_test_case) ? "Pass (Is GNF)" : "Fail (Not GNF)") << endl;
    
    printGrammar(second_test_case, 2);
    cout << "Grammar 2 check: " << (validateGNF(second_test_case) ? "Pass (Is GNF)" : "Fail (Not GNF)") << endl;
    
    printGrammar(third_test_case, 3);
    cout << "Grammar 3 check: " << (validateGNF(third_test_case) ? "Pass (Is GNF)" : "Fail (Not GNF)") << endl;

    return 0;
}

